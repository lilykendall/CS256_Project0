import java.util.Arrays;

public class Test {

    public static Void main(String[] args){

        int[] nums = {1,2,6,4,8,6,4};
        Arrays.sort(nums);
        System.out.println(nums);
        return null;
    }
}
